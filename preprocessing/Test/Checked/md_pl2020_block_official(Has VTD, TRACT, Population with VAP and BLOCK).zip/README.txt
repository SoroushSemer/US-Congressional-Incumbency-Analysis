2020 Redistricting Data for Maryland at the Block Level

These data are in compliance with Maryland State law​. 
This census data has been adjusted to reassign Maryland residents in state and federal correctional institutions to their last known address and to exclude out-of-state residents in correctional institutions from redistricting. 
All files contain the block and voting district data needed for redistricting.​

##Redistricting Data Hub (RDH) Retrieval Date
09/02/2021

##Sources
This dataset was retrieved from the Maryland Citizens Redistricting Commission at https://redistricting.maryland.gov/Pages/data.aspx

##Fields
For a list of fields, please refer to the DataDictionary.pdf file, which is included in this zip folder.

##Processing
The RDH retrieved the data from the source listed and did not modify any of the data.

##Additional Notes
For more information about this dataset, visit our PL 94-171 article at https://redistrictingdatahub.org/data/about-our-data/pl-94171-dataset/
For any additional questions, please email info@redistrictingdatahub.org