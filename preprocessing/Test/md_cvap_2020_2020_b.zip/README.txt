2020 Citizen Voting Age Population (CVAP) Data for Maryland from the American Community Survey (ACS) 5-Year Estimates (2016-2020) Disaggregated to 2020 Census Blocks

##Redistricting Data Hub (RDH) Retrieval Date
04/03/2022 for 2020 CVAP Data
04/03/2022 for 2020 Public Law 94-171 Data

##Sources
CVAP Data retrieved from the Census Citizen Voting Age Population by Race and Ethnicity website: https://www.census.gov/programs-surveys/decennial-census/about/voting-rights/cvap.2020.html
Public Law 94-171 Data was retrieved using the Census API, variables are available here: https://api.census.gov/data/2020/dec/pl/variables.html

##Fields
Field Name			Description

GEOID20                 Unique Identifier
COUNTYFP20			County FIPS Code
CVAP_TOT20              CVAP Estimate for Total
CVAP_NHS20              CVAP Estimate for Not Hispanic or Latino
CVAP_AIA20            	CVAP Estimate for American Indian or Alaska Native Alone or In Combination
CVAP_ASN20              CVAP Estimate for Asian Alone or In Combination
CVAP_BLK20              CVAP Estimate for Black or African American Alone or In Combination
CVAP_NHP20              CVAP Estimate for Native Hawaiian or Other Pacific Islander Alone
CVAP_WHT20              CVAP Estimate for White Alone
CVAP_AIW20              CVAP Estimate for American Indian or Alaska Native and White
CVAP_ASW20              CVAP Estimate for Asian and White
CVAP_BLW20              CVAP Estimate for Black or African American and White
CVAP_AIB20            	CVAP Estimate for American Indian or Alaska Native and Black or African American
CVAP_2OM20              CVAP Estimate for Remainder of Two or More Race Responses
CVAP_HSP20              CVAP Estimate for Hispanic or Latino      
C_TOT20                 Citizen Estimate for Total
C_NHS20                 Citizen Estimate for Not Hispanic or Latino
C_AIA20               	Citizen Estimate for American Indian or Alaska Native Alone or In Combination
C_ASN20                 Citizen Estimate for Asian Alone or In Combination
C_BLK20                 Citizen Estimate for Black or African American Alone or In Combination
C_NHP20                 Citizen Estimate for Native Hawaiian or Other Pacific Islander Alone
C_WHT20                 Citizen Estimate for White Alone
C_AIW20                 Citizen Estimate for American Indian or Alaska Native and White
C_ASW20                 Citizen Estimate for Asian and White
C_BLW20                 Citizen Estimate for Black or African American and White
C_AIB20         		Citizen Estimate for American Indian or Alaska Native and Black or African American
C_2OM20                 Citizen Estimate for Remainder of Two or More Race Responses
C_HSP20                 Citizen Estimate for Hispanic or Latino

##Processing
The processing for this dataset was completed in multiple parts.

Part 1: Processing the 2020 Block Group CVAP data

CVAP data was retrieved at the block group level from the link in "Sources" above.
The Maryland data was extracted from the national data to create a statewide dataset.
The data was pivoted from narrow to wide data based on GEOIDs so that one row is one block group, and each field represents a particular race/ethnicity. 
The fields were renamed to fit character length requirements. 
Processing was primarily completed using the pandas library.
To improve the usefulness of the data, we have modified three categories to correspond with the Office of Management and Budget (OMB) racial categories. The "Alone" categories for American Indian or Alaska Native (fields with "AIA"), Asian (fields with "ASN"), and Black or African American (fields with "BLK") represent an encompassing racial category that is inclusive of all categories that include that race. For example, CVAP_AIA19 would be the sum of the original "Alone" CVAP_AIA19, CVAP_AIB19, and CVAP_AIW19. For CVAP_BLK19, the field would be the sum of the original CVAP_BLK19, CVAP_AIB19, and CVAP_BLW19. For CVAP_ASN19, the field would be the sum of the original CVAP_ASN19 and CVAP_ASW19 These fields are also noted in the description as being "Alone or In Combination". No other estimate categories were modified.
All of the racial estimates provided are Non-Hispanic. Breakdowns for Hispanic/Non-Hispanic by race are not provided in the CVAP special tabulation.

Part 2: Disaggregating the 2020 Block Group CVAP data to 2020 Blocks

The 2020 CVAP data was disaggregated using 2020 PL 94-171 data. Using the Census API, the following variables were retrieved (some were summed, as indicated, to better resemble the OMB categories the CVAP modifications):
P4_001N		CVAPTOT20
P4_003N		CVAP_NHS20
P4_007N		CVAP_AIA20
P4_008N		CVAP_ASN20
P4_006N		CVAP_BLK20
P4_009N		CVAP_NHP20
P4_005N		CVAP_WHT20
P4_014N		CVAP_AIW20
P4_015N		CVAP_ASW20
P4_013N		CVAP_BLW20
P4_018N		CVAP_AIB20
P4_011N		CVAP_2OM20
P4_002N		CVAP_HSP20
P2_001N		C_TOT20
P2_003N		C_NHS20
P2_007N		C_AIA20
P2_008N		C_ASN20
P2_006N		C_BLK20
P2_009N		C_NHP20
P2_005N		C_WHT20
P2_014N		C_AIW20
P2_015N		C_ASW20
P2_013N		C_BLW20
P2_018N		C_AIB20
P2_011N		C_2OM20
P2_002N		C_HSP20
After retrieving the data from the API, the OMB categories were created using the same method as the 2020 block group CVAP data.

For each block in each column (e.g. CVAP_TOT20) the value for the 2020 block retrieved from the API was divided by the 2020 total for the block group.
The totals for the block group were retrieved by grouping the block data by block group ID. 
This provides a ratio of block to block group population for each individual racial category.
The ratios for each block in each column were multiplied by the 2020 CVAP total for the block's corresponding block group.
In the scenario where no blocks in a block group contain a value for a particular race/ethnicity combination in the 2020 PL 94-171 data, but have a value in the 2020 CVAP estimates, total CVAP population or total citizen estimate population were used as a proxy, depending on the variable.
In the scenario where no blocks in a block group contain a value for either the C_TOT20 category or CVAP_TOT20 categories, the 2020 CVAP dataset population is divided evenly amongst all blocks in the block group.
The results were rounded to the nearest hundredth.

All results were verified throughout the process to ensure that data was not being omitted and the totals of disaggregated data on 2020 blocks is nearly the same as the 2020 CVAP dataset block group totals (very slight differences may occur due to the lack of rounding until the final product).

##Additional Notes
For more information on the ACS CVAP documentation please refer to the ACS link above in Sources as well as the ACS technical documentation included in this folder (also available at this link: https://www2.census.gov/programs-surveys/decennial/rdo/technical-documentation/special-tabulation/CVAP_2016-2020_ACS_documentation_v3.pdf ).
For more information on OMB racial categories, please see this link: https://obamawhitehouse.archives.gov/omb/bulletins_b00-02/#n_1_
Visit the RDH GitHub and the processing script for this code here: https://github.com/nonpartisan-redistricting-datahub/
Please direct questions related to processing this dataset to info@redistrictingdatahub.org.