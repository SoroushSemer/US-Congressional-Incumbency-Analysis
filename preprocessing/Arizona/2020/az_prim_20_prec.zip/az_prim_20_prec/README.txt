2020 AZ Primary Precinct Boundary and Election Results

## RDH Date Retrieval
03/08/2022

## Sources
The RDH retrieved the VEST 2020 Primary precinct boundary and election results shapefile from [VEST's Harvard Dataverse](https://dataverse.harvard.edu/file.xhtml?fileId=4864722&version=27.0)
The RDH retrieved raw 2020 Primary election results from [Arizona's Secretary of State website](https://azsos.gov/2020-election-information)

## Notes on Field Names (adapted from VEST):
Columns reporting votes generally follow the pattern: 
The first character is G for a general election, P for a primary, S for a special, and R for a runoff.
Characters 2 and 3 are the year of the election.
Characters 4-6 represent the office type (see list below).
Character 7 represents the party of the candidate.
Characters 8-10 are the first three letters of the candidate's last name.
One example is:
G16PREDCLI

To fit within the GIS 10 character limit for field names, the naming convention is slightly different for the State Legislature and 
US House of Representatives. All fields are listed below with definitions.

Office Codes Used:
CON## - U.S. House, accompanied by a CON_DIST column indicating district number
COC - Corporation Commissioner
USS - U.S. Senate
SU## - State Legislative Upper District, accompanied by a SLDU_DIST column indicating district number
SL## - State Legislative Lower District, accompanied by a SLDL_DIST column indicating district number


## Fields:

Field Name                                                                           Description
                                                                                                
 UNIQUE_ID                                         Unique precinct name/identifier from SOS file
  COUNTYFP                                                          Three digit county fips code
    PCTNUM                                  Unique number identifier for precinct from VEST file
PRECINCTNA                                    Non-unique precinct name/identifier from VEST file
CDE_COUNTY                                            Two character county code from VEST's file
COUNTY_NAM                                                                        Name of county
  CON_DIST                                                     US Representative district number
 SLDL_DIST                                         State Legislative Lower Level district number
 SLDU_DIST                                         State Legislative Upper Level district number
P20USSDKEL                                                 Kelly, Mark (DEM), U.S. Senator (DEM)
P20USSRMCC                            McCarthy, Daniel "Demand Daniel" (REP), U.S. Senator (REP)
P20USSRMCS                                             McSally, Martha (REP), U.S. Senator (REP)
PCON01DOHA         O'Halleran, Tom (DEM), U.S. Representative in Congress - District No. 1 (DEM)
PCON01DPUT            Putzova, Eva (DEM), U.S. Representative in Congress - District No. 1 (DEM)
PCON01RREI         Reidhead, Nolan (REP), U.S. Representative in Congress - District No. 1 (REP)
PCON01RSHE          Shedd, Tiffany (REP), U.S. Representative in Congress - District No. 1 (REP)
PCON02DKIR        Kirkpatrick, Ann (DEM), U.S. Representative in Congress - District No. 2 (DEM)
PCON02DQUI          Quilter, Peter (DEM), U.S. Representative in Congress - District No. 2 (DEM)
PCON02RMAR         Martin, Brandon (REP), U.S. Representative in Congress - District No. 2 (REP)
PCON02RMOR          Morgan, Joseph (REP), U.S. Representative in Congress - District No. 2 (REP)
PCON02RRUD       Ruden, Noran Eric (REP), U.S. Representative in Congress - District No. 2 (REP)
PCON03DGRI          Grijalva, Raúl (DEM), U.S. Representative in Congress - District No. 3 (DEM)
PCON03RWOO            Wood, Daniel (REP), U.S. Representative in Congress - District No. 3 (REP)
PCON04DDIS         DiSanto, Delina (DEM), U.S. Representative in Congress - District No. 4 (DEM)
PCON04DSTA          Starky, Stuart (DEM), U.S. Representative in Congress - District No. 4 (DEM)
PCON04RGOS             Gosar, Paul (REP), U.S. Representative in Congress - District No. 4 (REP)
PCON04RWAR        Ward, Anne Marie (REP), U.S. Representative in Congress - District No. 4 (REP)
PCON05DGRE            Greene, Joan (DEM), U.S. Representative in Congress - District No. 5 (DEM)
PCON05DIRE            Ireland, Jon (DEM), U.S. Representative in Congress - District No. 5 (DEM)
PCON05DRAM           Ramos, Javier (DEM), U.S. Representative in Congress - District No. 5 (DEM)
PCON05RBIG             Biggs, Andy (REP), U.S. Representative in Congress - District No. 5 (REP)
PCON06DGEN           Gentles, Karl (DEM), U.S. Representative in Congress - District No. 6 (DEM)
PCON06DMAL            Malik, Anita (DEM), U.S. Representative in Congress - District No. 6 (DEM)
PCON06DRIM       Rimmer, Stephanie (DEM), U.S. Representative in Congress - District No. 6 (DEM)
PCON06DTIP        Tipirneni, Hiral (DEM), U.S. Representative in Congress - District No. 6 (DEM)
PCON06RSCH       Schweikert, David (REP), U.S. Representative in Congress - District No. 6 (REP)
PCON07DGAL          Gallego, Ruben (DEM), U.S. Representative in Congress - District No. 7 (DEM)
PCON07RBAR         Barnett, Joshua (REP), U.S. Representative in Congress - District No. 7 (REP)
PCON08DMU1         Muscato, Michael (DEM), U.S. Representative in Congress - District No. 8 (DEM)
PCON08DMU2         Musselwhite, Bob (DEM), U.S. Representative in Congress - District No. 8 (DEM)
PCON08DOLS     Olsen, Robert "Bob" (DEM), U.S. Representative in Congress - District No. 8 (DEM)
PCON08RLES           Lesko, Debbie (REP), U.S. Representative in Congress - District No. 8 (REP)
PCON09DSTA           Stanton, Greg (DEM), U.S. Representative in Congress - District No. 9 (DEM)
PCON09RGIL             Giles, Dave (REP), U.S. Representative in Congress - District No. 9 (REP)
PCON09RHUA              Huang, Sam (REP), U.S. Representative in Congress - District No. 9 (REP)
PCON09RTUT        Tutora, Nicholas (REP), U.S. Representative in Congress - District No. 9 (REP)
P20COCDMUN                         Mundell, William "Bill" (DEM), Corporation Commissioner (DEM)
P20COCDSTA                                 Stanfield, Shea (DEM), Corporation Commissioner (DEM)
P20COCDTOV                                     Tovar, Anna (DEM), Corporation Commissioner (DEM)
P20COCRMAR                           Marquez Peterson, Lea (REP), Corporation Commissioner (REP)
P20COCRSLO                                     Sloan, Eric (REP), Corporation Commissioner (REP)
 PSU01RFAN                    Fann, Karen Elizabeth (REP), State Senator - District No.  1 (REP)
 PSU02DGAB                        Gabaldón, Rosanna (DEM), State Senator - District No.  2 (DEM)
 PSU02RWOR                            Workman, Mark (REP), State Senator - District No.  2 (REP)
 PSU03DGON                      Gonzales, Sally Ann (DEM), State Senator - District No.  3 (DEM)
 PSU04DOTO                             Otondo, Lisa (DEM), State Senator - District No.  4 (DEM)
 PSU04RANG                            Angry, Travis (REP), State Senator - District No.  4 (REP)
 PSU05RBOR                          Borrelli, Sonny (REP), State Senator - District No.  5 (REP)
 PSU06DFRE                          French, Felicia (DEM), State Senator - District No.  6 (DEM)
 PSU06RALL                     Allen, Sylvia Tenney (REP), State Senator - District No.  6 (REP)
 PSU06RROG                            Rogers, Wendy (REP), State Senator - District No.  6 (REP)
 PSU07DPES                     Peshlakai, Jamescita (DEM), State Senator - District No.  7 (DEM)
 PSU08DMCG                         McGuire, Barbara (DEM), State Senator - District No.  8 (DEM)
 PSU08RSHO                     Shope, Thomas "T.J." (REP), State Senator - District No.  8 (REP)
 PSU09DSTE                         Steele, Victoria (DEM), State Senator - District No.  9 (DEM)
 PSU10DENG                           Engel, Kirsten (DEM), State Senator - District No. 10 (DEM)
 PSU10RWAD                         Wadsack, Justine (REP), State Senator - District No. 10 (REP)
 PSU11DMEN                          Mendoza, JoAnna (DEM), State Senator - District No. 11 (DEM)
 PSU11DPAT                         Patterson, Linda (DEM), State Senator - District No. 11 (DEM)
 PSU11RLEA                    Leach, Venden "Vince" (REP), State Senator - District No. 11 (REP)
 PSU12DROB                         Robinson, Lynsey (DEM), State Senator - District No. 12 (DEM)
 PSU12RPET                         Petersen, Warren (REP), State Senator - District No. 12 (REP)
 PSU13RKER                               Kerr, Sine (REP), State Senator - District No. 13 (REP)
 PSU14DKAR                                Karp, Bob (DEM), State Senator - District No. 14 (DEM)
 PSU14RGOW                             Gowan, David (REP), State Senator - District No. 14 (REP)
 PSU15RBAR                             Barto, Nancy (REP), State Senator - District No. 15 (REP)
 PSU15RCAR                          Carter, Heather (REP), State Senator - District No. 15 (REP)
 PSU16RTOW                          Townsend, Kelly (REP), State Senator - District No. 16 (REP)
 PSU17DKUR                   Kurdoglu, Ajlan "A.J." (DEM), State Senator - District No. 17 (DEM)
 PSU17RMES                            Mesnard, J.D. (REP), State Senator - District No. 17 (REP)
 PSU18DBOW                              Bowie, Sean (DEM), State Senator - District No. 18 (DEM)
 PSU18RSHA                          Sharer, Suzanne (REP), State Senator - District No. 18 (REP)
 PSU19DCHA                  Chavira Contreras, Lupe (DEM), State Senator - District No. 19 (DEM)
 PSU20DERV                           Ervin, Douglas (DEM), State Senator - District No. 20 (DEM)
 PSU20RBOY                              Boyer, Paul (REP), State Senator - District No. 20 (REP)
 PSU21RGRA                               Gray, Rick (REP), State Senator - District No. 21 (REP)
 PSU22DTYR                             Tyree, Sarah (DEM), State Senator - District No. 22 (DEM)
 PSU22RDIC                             DiCarlo, Van (REP), State Senator - District No. 22 (REP)
 PSU22RLIV                        Livingston, David (REP), State Senator - District No. 22 (REP)
 PSU22RNGU                              Nguyen, Hop (REP), State Senator - District No. 22 (REP)
 PSU23DBLA                           Blattman, Seth (DEM), State Senator - District No. 23 (DEM)
 PSU23RKOL                       Kolodin, Alexander (REP), State Senator - District No. 23 (REP)
 PSU23RUGE                    Ugenti-Rita, Michelle (REP), State Senator - District No. 23 (REP)
 PSU24DALS                             Alston, Lela (DEM), State Senator - District No. 24 (DEM)
 PSU24DSTA                            Starzyk, Ryan (DEM), State Senator - District No. 24 (DEM)
 PSU25DWEI                             Weigel, Paul (DEM), State Senator - District No. 25 (DEM)
 PSU25RPAC                              Pace, Tyler (REP), State Senator - District No. 25 (REP)
 PSU26DGRA                      Granillo, Jana Lynn (DEM), State Senator - District No. 26 (DEM)
 PSU26DMEN                             Mendez, Juan (DEM), State Senator - District No. 26 (DEM)
 PSU26RCHI                                Chin, Jae (REP), State Senator - District No. 26 (REP)
 PSU27DRIO                            Rios, Rebecca (DEM), State Senator - District No. 27 (DEM)
 PSU27RSHR                         Shreves, Garland (REP), State Senator - District No. 27 (REP)
 PSU28DMAR                         Marsh, Christine (DEM), State Senator - District No. 28 (DEM)
 PSU28RBRO                       Brophy McGee, Kate (REP), State Senator - District No. 28 (REP)
 PSU29DQUE                       Quezada, Martín J. (DEM), State Senator - District No. 29 (DEM)
 PSU29RWIL                             Wilson, John (REP), State Senator - District No. 29 (REP)
 PSU30DNAV                Navarrete, Otoniel "Tony" (DEM), State Senator - District No. 30 (DEM)
 PSL01DSTA                       Stahl, Judy (DEM), State Representative - District No.  1 (DEM)
 PSL01RBLI                     Bliss, Selina (REP), State Representative - District No.  1 (REP)
 PSL01RBUR                      Burges, Judy (REP), State Representative - District No.  1 (REP)
 PSL01RCOC                     Cocchiola, Ed (REP), State Representative - District No.  1 (REP)
 PSL01RNGU                     Nguyen, Quang (REP), State Representative - District No.  1 (REP)
 PSL01RSEN                 Sensmeier, Steven (REP), State Representative - District No.  1 (REP)
 PSL02DDAL               Dalessandro, Andrea (DEM), State Representative - District No.  2 (DEM)
 PSL02DHER            Hernandez, Daniel, Jr. (DEM), State Representative - District No.  2 (DEM)
 PSL02DPAR                       Parra, Luis (DEM), State Representative - District No.  2 (DEM)
 PSL02DPEA                      Peard, Billy (DEM), State Representative - District No.  2 (DEM)
 PSL02RMCE                   McEwen, Deborah (REP), State Representative - District No.  2 (REP)
 PSL03DCAN                      Cano, Andrés (DEM), State Representative - District No.  3 (DEM)
 PSL03DHER                   Hernandez, Alma (DEM), State Representative - District No.  3 (DEM)
 PSL03DSOT                      Soto, Javier (DEM), State Representative - District No.  3 (DEM)
 PSL04DFER               Fernandez, Charlene (DEM), State Representative - District No.  4 (DEM)
 PSL04DPET          Peten, Geraldine "Gerae" (DEM), State Representative - District No.  4 (DEM)
 PSL04RJOH                        John, Joel (REP), State Representative - District No.  4 (REP)
 PSL05RBIA                    Biasiucci, Leo (REP), State Representative - District No.  5 (REP)
 PSL05RCOB                      Cobb, Regina (REP), State Representative - District No.  5 (REP)
 PSL06DEVA                    Evans, Coral J (DEM), State Representative - District No.  6 (DEM)
 PSL06RBAR                    Barton, Brenda (REP), State Representative - District No.  6 (REP)
 PSL06RBLA           Blackman, Walter "Walt" (REP), State Representative - District No.  6 (REP)
 PSL07DTEL                   Teller, Arlando (DEM), State Representative - District No.  7 (DEM)
 PSL07DTSO                     Tsosie, Myron (DEM), State Representative - District No.  7 (DEM)
 PSL07RPAR                Parks, James "Jim" (REP), State Representative - District No.  7 (REP)
 PSL07RPEE                    Peelman, David (REP), State Representative - District No.  7 (REP)
 PSL08DGIR                    Girard, Sharon (DEM), State Representative - District No.  8 (DEM)
 PSL08RCAR                      Carter, Neal (REP), State Representative - District No.  8 (REP)
 PSL08RCOO                       Cook, David (REP), State Representative - District No.  8 (REP)
 PSL08RPRA                      Pratt, Frank (REP), State Representative - District No.  8 (REP)
 PSL09DFRI           Friese, Randall "Randy" (DEM), State Representative - District No.  9 (DEM)
 PSL09DPOW            Powers Hannley, Pamela (DEM), State Representative - District No.  9 (DEM)
 PSL09RLYO                    Lyons, Brendan (REP), State Representative - District No.  9 (REP)
 PSL10DDEG                 DeGrazia, Domingo (DEM), State Representative - District No. 10 (DEM)
 PSL10DSTA             Stapleton-Smith, Paul (DEM), State Representative - District No. 10 (DEM)
 PSL10RGUM                  Gummere, Mabelle (REP), State Representative - District No. 10 (REP)
 PSL10RHIC                    Hicks, Michael (REP), State Representative - District No. 10 (REP)
 PSL11DPER                   Perez, Felipe R (DEM), State Representative - District No. 11 (DEM)
 PSL11RFIN                     Finchem, Mark (REP), State Representative - District No. 11 (REP)
 PSL11RROB                     Roberts, Bret (REP), State Representative - District No. 11 (REP)
 PSL12RGRA                  Grantham, Travis (REP), State Representative - District No. 12 (REP)
 PSL12RHOF                     Hoffman, Jake (REP), State Representative - District No. 12 (REP)
 PSL13DSAN                 Sandoval, Mariana (DEM), State Representative - District No. 13 (DEM)
 PSL13RDUN               Dunn, Timothy "Tim" (REP), State Representative - District No. 13 (REP)
 PSL13RMON                 Montenegro, Steve (REP), State Representative - District No. 13 (REP)
 PSL13ROSB                   Osborne, Joanne (REP), State Representative - District No. 13 (REP)
 PSL14DBEA Beach - Moschetti, Kimberly "Kim" (DEM), State Representative - District No. 14 (DEM)
 PSL14DMAE            Maestas-Condos, Ronnie (DEM), State Representative - District No. 14 (DEM)
 PSL14RGRI                     Griffin, Gail (REP), State Representative - District No. 14 (REP)
 PSL14RNUT                       Nutt, Becky (REP), State Representative - District No. 14 (REP)
 PSL15DDYB           Dybvig-Pawelko, Kristin (DEM), State Representative - District No. 15 (DEM)
 PSL15RHAM                 Hamstreet, Jarret (REP), State Representative - District No. 15 (REP)
 PSL15RKAI                     Kaiser, Steve (REP), State Representative - District No. 15 (REP)
 PSL15RWIL                   Wilmeth, Justin (REP), State Representative - District No. 15 (REP)
 PSL16RFIL                    Fillmore, John (REP), State Representative - District No. 16 (REP)
 PSL16RGOD                     Godzich, Lisa (REP), State Representative - District No. 16 (REP)
 PSL16RMOR             Moriarty, Forest John (REP), State Representative - District No. 16 (REP)
 PSL16RPAR                Parker, Jacqueline (REP), State Representative - District No. 16 (REP)
 PSL17DPAW                  Pawlik, Jennifer (DEM), State Representative - District No. 17 (DEM)
 PSL17RHAR                       Harris, Liz (REP), State Representative - District No. 17 (REP)
 PSL17RWEN                    Weninger, Jeff (REP), State Representative - District No. 17 (REP)
 PSL18DEPS           Epstein, Denise "Mitzi" (DEM), State Representative - District No. 18 (DEM)
 PSL18DJER                Jermaine, Jennifer (DEM), State Representative - District No. 18 (DEM)
 PSL18RROB                       Robson, Bob (REP), State Representative - District No. 18 (REP)
 PSL19DESP                   Espinoza, Diego (DEM), State Representative - District No. 19 (DEM)
 PSL19DSIE                   Sierra, Lorenzo (DEM), State Representative - District No. 19 (DEM)
 PSL19DSUN                       Sun, Leezah (DEM), State Representative - District No. 19 (DEM)
 PSL20DSCH                  Schwiebert, Judy (DEM), State Representative - District No. 20 (DEM)
 PSL20RBOL                   Bolick, Shawnna (REP), State Representative - District No. 20 (REP)
 PSL20RKER                     Kern, Anthony (REP), State Representative - District No. 20 (REP)
 PSL21DKNE                     Knecht, Kathy (DEM), State Representative - District No. 21 (DEM)
 PSL21RMIL                     Miller, Randy (REP), State Representative - District No. 21 (REP)
 PSL21RPAY                      Payne, Kevin (REP), State Representative - District No. 21 (REP)
 PSL21RPIN               Pingerelli, Beverly (REP), State Representative - District No. 21 (REP)
 PSL22DGAR                     Garcia, Wendy (DEM), State Representative - District No. 22 (DEM)
 PSL22DHON            Honne, Mary "Kathleen" (DEM), State Representative - District No. 22 (DEM)
 PSL22RCAR                    Carroll, Frank (REP), State Representative - District No. 22 (REP)
 PSL22RTOM                         Toma, Ben (REP), State Representative - District No. 22 (REP)
 PSL23DKUR                     Kurland, Eric (DEM), State Representative - District No. 23 (DEM)
 PSL23RCHA                   Chaplik, Joseph (REP), State Representative - District No. 23 (REP)
 PSL23RKAV                    Kavanagh, John (REP), State Representative - District No. 23 (REP)
 PSL23RLAW                     Lawrence, Jay (REP), State Representative - District No. 23 (REP)
 PSL24DLON                 Longdon, Jennifer (DEM), State Representative - District No. 24 (DEM)
 PSL24DSHA                       Shah, Amish (DEM), State Representative - District No. 24 (DEM)
 PSL25DHUG                      Hug, Suzanne (DEM), State Representative - District No. 25 (DEM)
 PSL25RBOW        Bowers, Russell W. "Rusty" (REP), State Representative - District No. 25 (REP)
 PSL25RPEA                     Pearce, Kathy (REP), State Representative - District No. 25 (REP)
 PSL25RUDA                   Udall, Michelle (REP), State Representative - District No. 25 (REP)
 PSL26DHER                 Hernandez, Melody (DEM), State Representative - District No. 26 (DEM)
 PSL26DMOR                  Morales, Patrick (DEM), State Representative - District No. 26 (DEM)
 PSL26DNEZ                Nez-Manuel, Debbie (DEM), State Representative - District No. 26 (DEM)
 PSL26DSAL                    Salman, Athena (DEM), State Representative - District No. 26 (DEM)
 PSL26RLOU                   Loughrige, Bill (REP), State Representative - District No. 26 (REP)
 PSL26RSIF        Sifuentes, Seth ""Marcus"" (REP), State Representative - District No. 26 (REP)
 PSL27DBOL                 Bolding, Reginald (DEM), State Representative - District No. 27 (DEM)
 PSL27DMIR                Miranda, Catherine (DEM), State Representative - District No. 27 (DEM)
 PSL27DROD                  Rodriguez, Diego (DEM), State Representative - District No. 27 (DEM)
 PSL27RPEN                  Peña M., Tatiana (REP), State Representative - District No. 27 (REP)
 PSL28DBUT                     Butler, Kelli (DEM), State Representative - District No. 28 (DEM)
 PSL28DLIE                  Lieberman, Aaron (DEM), State Representative - District No. 28 (DEM)
 PSL28RBOW       Bowers, Kenneth R "Ken", Jr (REP), State Representative - District No. 28 (REP)
 PSL28RJAC                     Jackson, Jana (REP), State Representative - District No. 28 (REP)
 PSL29DAND                  Andrade, Richard (DEM), State Representative - District No. 29 (DEM)
 PSL29DCAS                     Castro, Teddy (DEM), State Representative - District No. 29 (DEM)
 PSL29DCHA                     Chavez, Cesar (DEM), State Representative - District No. 29 (DEM)
 PSL29RBRA                      Bragg, Billy (REP), State Representative - District No. 29 (REP)
 PSL29RFOK          FokszanskyJ-Conti, Helen (REP), State Representative - District No. 29 (REP)
 PSL29RMCM     McMillan, Alysia "Ariesuptop" (REP), State Representative - District No. 29 (REP)
 PSL30DMEZ                      Meza, Robert (DEM), State Representative - District No. 30 (DEM)
 PSL30DTER                     Terán, Raquel (DEM), State Representative - District No. 30 (DEM)
  geometry                                                                              geometry
                                                                                                

                                                                                                
## Processing Steps
The RDH joined additional election results to VEST's existing precinct shapefile, including House of Representatives, US Senate, SLDL, SLDU, and Corporation Commissioner using Python.
For more information on the processing completed, visit our [Github repository](https://github.com/nonpartisan-redistricting-datahub/erj-az) for Election Result Joins (ERJ) for Arizona.

Where possible, the RDH validated the election results we processed against VEST's election results. For additional races the RDH manually checked state totals. For more information on this comparison, please see our processing on Github (https://github.com/nonpartisan-redistricting-datahub/erj-az).

## Additional Notes
The AZ Presidential Preference Election took place on March 17, 2020 and results are available
as a PDF from the SOS (https://azsos.gov/sites/default/files/PPE%20Canvass%20Signed%203.30.2020.pdf). 

The RDH did not process them at this time as they were not available at the precinct level, nor 
included outside of the PDF.


Please contact info@redistrictingdatahub.org for more information.
