2022 Arizona Congressional Plan

##Redistricting Data Hub (RDH) Retrieval Date
01/24/2022

##Sources
This dataset was retrieved from the Arizona Independent Redistricting Commission website: https://redistricting-irc-az.hub.arcgis.com/pages/official-maps#background

##Processing
The RDH retrieved the data from the source listed and did not modify any of the data.

##Additional Notes
Enclosed in this zip file the shapefile for Arizona's Congressional Districts ("Approved_Official_Congressional_Map.shp"), an audit log ("Arizona_Official_Congressional_Map_Audit_Log.pdf"), a block equivalency file ("Approved_Official_Congressional_Map.txt"), a demographic and competitive data analysis report ("plan_summary_-_Official_Congressional_Map.pdf"), an assigned district splits report ("ApprovedOfficialCongressionalMapAssignedDistrictSplits.pdf"), a district compactness report ("ApprovedOfficialCongressionalMapDistrictCompactnessReport.pdf"), a district map ("Congressional_Large_Approved_Official_Map.pdf"), and inividual district maps ("Congressional_Individual_Approved_Official_Map.pdf").

To keep track of a state's adopted maps, go to All About Redistricting https://redistricting.lls.edu/
For any additional questions, please email info@redistrictingdatahub.org