2022 Louisiana Congressional Plan

##Redistricting Data Hub (RDH) Retrieval Date
04/01/2022

##Sources
This dataset was retrieved from the Louisiana Legislature: https://redist.legis.la.gov/ShapeFilesFromEnrolledBills
The State Senate shapefile is "House Bill 1 - Enrolled - Congress".

##Processing
The RDH did not modify any of the data.

##Additional Notes
Enclosed in this zip file the shapefile file for Louisiana's State Senate Districts ("HB1_Congress_221ES.shp") and supporting files.

To keep track of a state's adopted maps, go to All About Redistricting https://redistricting.lls.edu/
For any additional questions, please email info@redistrictingdatahub.org