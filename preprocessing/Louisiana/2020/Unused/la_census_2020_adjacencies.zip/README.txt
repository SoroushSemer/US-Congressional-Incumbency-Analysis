2020 Census Geography Adjacencies for Louisiana

Please note that Louisiana made modifications to the 2020 Census geographies as part of its redistricting datasets. Adjacencies are calculated on these geographies and marked with '_official_' in the file name.
Louisiana released modified VTD geographies. Please see the 'States that Adjust the Census Data for Redistricting' project on the RDH website for more details.

##Redistricting Data Hub (RDH) Retrieval Date
07/27/22

##Sources
2020 Census Geographies were retrieved from the Redistricting Data Hub website.

##Fields
Field Name                               Description
GEOID20                            Census 2020 GEOID
ADJ_GEOMS    List of GEOID20s of adjacent geometries

##Processing
2020 Census geographies were obtained from the RDH website. 
Adjacencies were calculated by intersecting the geometries with themselves, filtering out self-intersections, and then appending all other intersections to a list.
For the rook adjacency files, point adjacencies were filtered out.
GEOID20 values with no adjacencies were added with a blank ADJ_GEOMS list.
Finally, the files are sorted by GEOID20.

##Additional Notes

Please note that adjacencies are calculated within states.
For example, the adjacency between one county and another county it touches in another state would not appear in this file.
AIANNH areas may extend into other states, but for the purposes of this file adjacencies are only recorded for bordering AIANNH areas within the state.
Adjacencies in these files are calculated solely using geometries.
States may have rules for things like island adjacency that will not be captured in these files.
In order for polygons to be rook adjacent, their shared border must have a length.
For polygons to be queen adjacent, their shared border can be as small as a single point.
As an example, the states of Colorado and Arizona are queen adjacent, but not rook adjacent.
Different states have different rules regarding rook vs. queen adjacency in redistricting. 

For additional questions, email info@redistrictingdatahub.org.