2020 Redistricting Data for Louisiana at the Voting Tabulation District (VTD) level with Block Equivalency File

This Shapefile is the U.S. Census Bureau's 2020 TIGER/Line Shapefile VTD Layer, as validated through the data verification program of the House and Senate. The data verification program identified discrepancies in the original 2020 TIGER/Line Shapefile VTD Layer in the following Parishes: Avoyelles, Caddo, Plaquemines, West Baton Rouge and Vermilion. This validated Shapefile is the VTD Shapefile that will be utilized by the Louisiana Legislature.

This Block Equivalency File is the relationship file between the 2020 Census Blocks and the U.S. Census Bureau's Census 2020 TIGER/Line Shapefile VTD Layer, as validated through the data verification program of the House and Senate and corrects discrepancies identified in the original 2020 TIGER/Line Shapefile VTD Layer in the following Parishes: Avoyelles, Caddo, Plaquemines, West Baton Rouge and Vermilion. This Block Equivalency File reflects the assignment of 2020 Census Blocks to the validated VTDs that will be utilized by the Louisiana Legislature.

##Redistricting Data Hub (RDH) Retrieval Date
09/09/2021

##Sources
This dataset was retrieved from the Louisiana Legislature at https://redist.legis.la.gov/default_ShapeFiles2020#

##Processing
The RDH retrieved the data from the source listed and did not modify any of the data.

##Additional Notes
For more information about this dataset, visit our PL 94-171 article at https://redistrictingdatahub.org/data/about-our-data/pl-94171-dataset/
For any additional questions, please email info@redistrictingdatahub.org