L2 Voter File 2020 Elections Turnout Statistics for MD, aggregated to the 2020 VTD level 

## Redistricting Data Hub (RDH) Retrieval Date
10/22/2021

## Sources
The Redistricting Data Hub purchased this Voter File from L2, a national Voter File vendor: https://l2-data.com/

## Fields
The fields below were pulled from the L2 Voter File, dated 8/22/2021. 
To see more detailed field descriptions, please view the attached data dictionary provided by L2. 
All fields are for individuals who are registered on the L2 Voter File as of 8/22/2021. The RDH did not have access to legacy or snapshot voter files. 

Field Name               		Description
vtd_geoid20              		11-character GEOID corresponding to 2020 Census VTDs, based on L2 geo-referencing of individual voter addresses
total_reg                		Count of total registered voters in the Census Block, as geo-referenced by L2, on the 8/22/2021 L2 Voter File
g20201103_voted_all      		Count of voters who voted in the following election: general_2020_11_03
g20201103_reg_all        		Count of voters registered on or before: 2020-11-03
g20201103_pct_voted_all  		Percent of voters registered on or before 2020-11-03 and who voted in: general_2020_11_03
g20201103_voted_eur      		Count of voters who voted in the following election: general_2020_11_03, L2 Race or Ethnicity: European
g20201103_reg_eur        		Count of voters registered on or before: 2020-11-03, L2 Race or Ethnicity: European
g20201103_pct_voted_eur  		Percent of voters registered on or before 2020-11-03 and who voted in: general_2020_11_03, L2 Race or Ethnicity: European
g20201103_voted_hisp     		Count of voters who voted in the following election: general_2020_11_03, L2 Race or Ethnicity: Hispanic and Portuguese
g20201103_reg_hisp       		Count of voters registered on or before: 2020-11-03, L2 Race or Ethnicity: Hispanic and Portuguese
g20201103_pct_voted_hisp 		Percent of voters registered on or before 2020-11-03 and who voted in: general_2020_11_03, L2 Race or Ethnicity: Hispanic and Portuguese
g20201103_voted_aa       		Count of voters who voted in the following election: general_2020_11_03, L2 Race or Ethnicity: Likely African-American
g20201103_reg_aa         		Count of voters registered on or before: 2020-11-03, L2 Race or Ethnicity: Likely African-American
g20201103_pct_voted_aa   		Percent of voters registered on or before 2020-11-03 and who voted in: general_2020_11_03, L2 Race or Ethnicity: Likely African-American
g20201103_voted_esa      		Count of voters who voted in the following election: general_2020_11_03, L2 Race or Ethnicity: East and South Asian
g20201103_reg_esa        		Count of voters registered on or before: 2020-11-03, L2 Race or Ethnicity: East and South Asian
g20201103_pct_voted_esa  		Percent of voters registered on or before 2020-11-03 and who voted in: general_2020_11_03, L2 Race or Ethnicity: East and South Asian
g20201103_voted_oth      		Count of voters who voted in the following election: general_2020_11_03, L2 Race or Ethnicity: Other
g20201103_reg_oth        		Count of voters registered on or before: 2020-11-03, L2 Race or Ethnicity: Other
g20201103_pct_voted_oth  		Percent of voters registered on or before 2020-11-03 and who voted in: general_2020_11_03, L2 Race or Ethnicity: Other
g20201103_voted_unk      		Count of voters who voted in the following election: general_2020_11_03, L2 Race or Ethnicity: Unknown
g20201103_reg_unk        		Count of voters registered on or before: 2020-11-03, L2 Race or Ethnicity: Unknown
g20201103_pct_voted_unk  		Percent of voters registered on or before 2020-11-03 and who voted in: general_2020_11_03, L2 Race or Ethnicity: Unknown
pp20200602_voted_all     		Count of voters who voted in the following election: presidential_primary_2020_06_02
pp20200602_reg_all       		Count of voters registered on or before: 2020-06-02
pp20200602_pct_voted_all 		Percent of voters registered on or before 2020-06-02 and who voted in: presidential_primary_2020_06_02
pp20200602_voted_eur     		Count of voters who voted in the following election: presidential_primary_2020_06_02, L2 Race or Ethnicity: European
pp20200602_reg_eur       		Count of voters registered on or before: 2020-06-02, L2 Race or Ethnicity: European
pp20200602_pct_voted_eur 		Percent of voters registered on or before 2020-06-02 and who voted in: presidential_primary_2020_06_02, L2 Race or Ethnicity: European
pp20200602_voted_hisp    		Count of voters who voted in the following election: presidential_primary_2020_06_02, L2 Race or Ethnicity: Hispanic and Portuguese
pp20200602_reg_hisp      		Count of voters registered on or before: 2020-06-02, L2 Race or Ethnicity: Hispanic and Portuguese
pp20200602_pct_voted_hisp		Percent of voters registered on or before 2020-06-02 and who voted in: presidential_primary_2020_06_02, L2 Race or Ethnicity: Hispanic and Portuguese
pp20200602_voted_aa      		Count of voters who voted in the following election: presidential_primary_2020_06_02, L2 Race or Ethnicity: Likely African-American
pp20200602_reg_aa        		Count of voters registered on or before: 2020-06-02, L2 Race or Ethnicity: Likely African-American
pp20200602_pct_voted_aa  		Percent of voters registered on or before 2020-06-02 and who voted in: presidential_primary_2020_06_02, L2 Race or Ethnicity: Likely African-American
pp20200602_voted_esa     		Count of voters who voted in the following election: presidential_primary_2020_06_02, L2 Race or Ethnicity: East and South Asian
pp20200602_reg_esa       		Count of voters registered on or before: 2020-06-02, L2 Race or Ethnicity: East and South Asian
pp20200602_pct_voted_esa 		Percent of voters registered on or before 2020-06-02 and who voted in: presidential_primary_2020_06_02, L2 Race or Ethnicity: East and South Asian
pp20200602_voted_oth     		Count of voters who voted in the following election: presidential_primary_2020_06_02, L2 Race or Ethnicity: Other
pp20200602_reg_oth       		Count of voters registered on or before: 2020-06-02, L2 Race or Ethnicity: Other
pp20200602_pct_voted_oth 		Percent of voters registered on or before 2020-06-02 and who voted in: presidential_primary_2020_06_02, L2 Race or Ethnicity: Other
pp20200602_voted_unk     		Count of voters who voted in the following election: presidential_primary_2020_06_02, L2 Race or Ethnicity: Unknown
pp20200602_reg_unk       		Count of voters registered on or before: 2020-06-02, L2 Race or Ethnicity: Unknown
pp20200602_pct_voted_unk 		Percent of voters registered on or before 2020-06-02 and who voted in: presidential_primary_2020_06_02, L2 Race or Ethnicity: Unknown
p20200602_voted_all      		Count of voters who voted in the following election: primary_2020_06_02
p20200602_reg_all        		Count of voters registered on or before: 2020-06-02
p20200602_pct_voted_all  		Percent of voters registered on or before 2020-06-02 and who voted in: primary_2020_06_02
p20200602_voted_eur      		Count of voters who voted in the following election: primary_2020_06_02, L2 Race or Ethnicity: European
p20200602_reg_eur        		Count of voters registered on or before: 2020-06-02, L2 Race or Ethnicity: European
p20200602_pct_voted_eur  		Percent of voters registered on or before 2020-06-02 and who voted in: primary_2020_06_02, L2 Race or Ethnicity: European
p20200602_voted_hisp     		Count of voters who voted in the following election: primary_2020_06_02, L2 Race or Ethnicity: Hispanic and Portuguese
p20200602_reg_hisp       		Count of voters registered on or before: 2020-06-02, L2 Race or Ethnicity: Hispanic and Portuguese
p20200602_pct_voted_hisp 		Percent of voters registered on or before 2020-06-02 and who voted in: primary_2020_06_02, L2 Race or Ethnicity: Hispanic and Portuguese
p20200602_voted_aa       		Count of voters who voted in the following election: primary_2020_06_02, L2 Race or Ethnicity: Likely African-American
p20200602_reg_aa         		Count of voters registered on or before: 2020-06-02, L2 Race or Ethnicity: Likely African-American
p20200602_pct_voted_aa   		Percent of voters registered on or before 2020-06-02 and who voted in: primary_2020_06_02, L2 Race or Ethnicity: Likely African-American
p20200602_voted_esa      		Count of voters who voted in the following election: primary_2020_06_02, L2 Race or Ethnicity: East and South Asian
p20200602_reg_esa        		Count of voters registered on or before: 2020-06-02, L2 Race or Ethnicity: East and South Asian
p20200602_pct_voted_esa  		Percent of voters registered on or before 2020-06-02 and who voted in: primary_2020_06_02, L2 Race or Ethnicity: East and South Asian
p20200602_voted_oth      		Count of voters who voted in the following election: primary_2020_06_02, L2 Race or Ethnicity: Other
p20200602_reg_oth        		Count of voters registered on or before: 2020-06-02, L2 Race or Ethnicity: Other
p20200602_pct_voted_oth  		Percent of voters registered on or before 2020-06-02 and who voted in: primary_2020_06_02, L2 Race or Ethnicity: Other
p20200602_voted_unk      		Count of voters who voted in the following election: primary_2020_06_02, L2 Race or Ethnicity: Unknown
p20200602_reg_unk        		Count of voters registered on or before: 2020-06-02, L2 Race or Ethnicity: Unknown
p20200602_pct_voted_unk  		Percent of voters registered on or before 2020-06-02 and who voted in: primary_2020_06_02, L2 Race or Ethnicity: Unknown

## Processing
L2 assigns each voter to a 2010 Census Block on their Voter File. 
L2 provided the RDH with a file that has each individual and their corresponding 2020 Census Block, dated 9/1/2021. 
The RDH joined the L2 Voter File to this 2020 Census Block assignment file. 
The RDH then aggregated the individual level Voter File to the Census Block level. 
The RDH then used the 2020 Census Block to VTD Assignment files to aggregate the 2020 Census Block level to the 2020 VTD level. 
Processing was completed using SQL and Python. 
The RDH cannot certify the accuracy of any of the information contained within this file, or that the 2020 VTDs were the accurate geographies used for the elections contained in the file. 

## Additional Notes
The VTD GEOID is composed of: 2-character State Fips + 3-Character County Fips + 6 character VTD ID

Please contact info@redistrictingdatahub.org for more information.