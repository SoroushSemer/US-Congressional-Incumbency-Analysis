Maryland 2022 Primary Candidate Political, Demographic and Endorsement Information

## Redistricting Data Hub (RDH) Retrieval Date
11/23/22
    
## Sources
538

Electoral, endorsement and gender data was collected by FiveThirtyEight from state election officials, organization websites, social media and the [Center for American Women and Politics](https://cawp.rutgers.edu). Race data was collected by political scientists [Bernard Fraga](http://polisci.emory.edu/home/people/biography/fraga-bernard.html) and [Hunter Rendleman](https://hunterrendleman.com) using statements made by candidates, membership in racial and ethnic caucuses or organizations, racial and ethnic advocacy organizations, news reports and candidate websites.

Sources for particular fields:
Column                   Source
Candidate                Official candidate lists and election results on state government websites.
Party                    Column added by RDH using candidate presence in either Democratic or Republican file.
Gender                   The Center for American Women and Politics’s [website](https://cawp.rutgers.edu/election-watch/2022-summary-women-candidates), candidate websites and news reports.
Race 1                   Statements made by candidates, membership in racial and ethnic caucuses or organizations, racial and ethnic advocacy organizations, news reports and candidate websites. Data collected by political scientists Bernard Fraga and Hunter Rendleman.
Race 2                   Statements made by candidates, membership in racial and ethnic caucuses or organizations, racial and ethnic advocacy organizations, news reports and candidate websites. Data collected by political scientists Bernard Fraga and Hunter Rendleman.
Race 3                   Statements made by candidates, membership in racial and ethnic caucuses or organizations, racial and ethnic advocacy organizations, news reports and candidate websites. Data collected by political scientists Bernard Fraga and Hunter Rendleman.
Incumbent                Official U.S. Senate, U.S. House or state gubernatorial websites.
Incumbent Challenger     Official U.S. Senate, U.S. House or state gubernatorial websites.
State                    State government websites.
Primary Date             State government websites.
Office                   Official candidate lists and election results on state government websites.
District                 Official candidate lists and election results on state government websites.
Primary Votes            Official election results on state government websites.
Primary %                Official election results on state government websites.
Primary Outcome          Official election results on state government websites.
Runoff Votes             Official election results on state government websites.
Runoff %                 Official election results on state government websites.
Runoff Outcome           Official election results on state government websites.
EMILY's List             [EMILY’s](https://emilyslist.org/candidates/gallery/senate) [List’s](https://emilyslist.org/candidates/gallery/house) [website.](https://emilyslist.org/candidates/gallery/governor)
Justice Dems             Justice Democrats’s [website](https://www.justicedemocrats.com/candidates).
Indivisible              Indivisible’s [website](https://indivisible.org/candidates).
PCCC                     The PCCC’s [website](https://www.boldprogressives.org/candidates/).
Our Revolution           Our Revolution’s [website](https://ourrevolution.com/endorsements/).
Sunrise                  The Sunrise Movement’s [website](https://www.sunrisemovement.org/political-endorsements/).
Sanders                  Sanders’s [Twitter account](https://twitter.com/search?q=from%3A%40berniesanders%20endorse%20OR%20endorsement&src=typed_query&f=live) and news reports.
AOC                      Ocasio-Cortez’s [Twitter account](https://twitter.com/search?q=from%3A%40aoc%20endorse%20OR%20endorses%20OR%20endorsing%20OR%20endorsement&src=typed_query&f=live), her email list and news reports.
Party Committee          The DCCC’s [website](https://redtoblue.dccc.org), DSCC [press releases](https://www.dscc.org/news/) and news reports.
Trump                    Trump’s [website](https://www.donaldjtrump.com/news), his [TruthSocial account](https://www.donaldjtrump.com/news) and news reports.
Trump Date               Trump’s [website](https://www.donaldjtrump.com/news), his [TruthSocial account](https://www.donaldjtrump.com/news) and news reports.
Club for Growth          The Club for Growth’s [website](https://www.clubforgrowth.org/elections/pac-endorsed-candidates/).
Party Committee          The NRCC’s [website](https://gopyoungguns.com) and news reports.
Renew America            The Renew America Movement’s [website](https://renewamericamovement.com/renewers/).
E-PAC                    E-PAC’s [website](https://elevate-pac.com/our-candidates/).
VIEW PAC                 VIEW PAC’s [website](https://viewpac.org/who-we-support/).
Maggie’s List            Maggie’s List’s [website](http://maggieslist.org/candidates/2022-candidates).
Winning for Women        Winning for Women’s [website](https://winningforwomen.com/2022-candidates/).

    
## Fields
Column                   Description
Candidate                Name
Party                    Candidate's party.
Gender                   Candidate's gender.
Race 1                   Race or ethnicity (including Hispanic origin) the candidate primarily identifies as.
Race 2                   Race or ethnicity (including Hispanic origin) the candidate secondarily identifies as, if any.
Race 3                   Race or ethnicity (including Hispanic origin) the candidate tertiarily identifies as, if any.
Incumbent                Whether the candidate was an incumbent.
Incumbent Challenger     Whether one of the candidate’s opponents in the primary was an incumbent.
State                    The state in which the candidate ran.
Primary Date             Date of the candidate's primary.
Office                   The office for which the candidate ran.
District                 For U.S. House races, the congressional district number for which the candidate ran.
Primary Votes            The raw number of votes received by the candidate in his or her primary. In states with runoffs, the results of the first primary round are used. For races that were canceled because they were uncontested, this number is 1.
Primary %                The percentage of the vote received by the candidate in his or her primary. In states with all-party primaries, this is the percentage of the Democratic or Republican vote received by the candidate. In states with runoffs, the results of the first primary round are used. For candidates who were unopposed, this number is 100.
Primary Outcome          Whether the candidate “Won” or “Lost” his or her primary or, if applicable, “Made runoff.”
Runoff Votes             The raw number of votes received by the candidate in his or her runoff, if applicable.
Runoff %                 The percentage of the vote received by the candidate in his or her runoff, if applicable.
Runoff Outcome           Whether the candidate “Won” or “Lost” his or her runoff, if applicable.
EMILY's List             (Dem. only) Endorsed by EMILY’s List.
Justice Dems             (Dem. only) Endorsed by Justice Democrats.
Indivisible              (Dem. only) Endorsed by Indivisible.
PCCC                     (Dem. only) Endorsed by the Progressive Change Campaign Committee.
Our Revolution           (Dem. only) Endorsed by Our Revolution.
Sunrise                  (Dem. only) Endorsed by the Sunrise Movement.
Sanders                  (Dem. only) Endorsed by Sen. Bernie Sanders.
AOC                      (Dem. only) Endorsed by Rep. Alexandria Ocasio-Cortez.
Party Committee          (Dem. only) On DCCC’s Red to Blue list, endorsed by the DSCC or an incumbent Dem. gov. (the Democratic Governors Association has a policy of always supporting incumbents but not getting involved in primaries that do not feature incumbents).
Trump                    (Rep. only) Endorsed by former President Donald Trump.
Trump Date               Date endorsed by Trump.
Club for Growth          (Rep. only) Endorsed by the Club for Growth.
Party Committee          (Rep. only) Whether the candidate reached the highest tier of the National Republican Congressional Committee’s Young Guns program or is an incumbent Republican senator or governor (the National Republican Senatorial Committee and Republican Governors Association had policies in 2022 of always supporting incumbents but not getting involved in primaries that do not feature incumbents).
Renew America            (Rep. only) Whether the candidate is listed as a “Renewer” (marked as “Yes”) or a “Divider” (marked as “No”) by the Renew America Movement.
E-PAC                    (Rep. only) Endorsed by E-PAC.
VIEW PAC                 (Rep. only) Endorsed by VIEW PAC.
Maggie’s List            (Rep. only) Endorsed by Maggie’s List.
Winning for Women        (Rep. only) Endorsed by Winning for Women.

    
## Processing
538's data was originally split into two files depending on a candidate's party. The RDH added a 'Party' column to each file and combined the files. Please note that there are a handful of endorsement columns that are only relevant to candidates in one party.
    
## Additional Notes
For the endorsement fields, “Yes” indicates that the candidate was endorsed by the organization or person in question before the primary. In states with runoff elections, if an organization or person issued an endorsement after the primary but before the runoff, that is indicated by “Yes (runoff only).” “N/A” is used if the organization or person did not weigh in on the race in question. “No” is reserved only for when the endorser is supporting a candidate’s opponent or if they specifically opposed the candidate. Note that endorsements only count if issued by the national arm of each organization; endorsements by local chapters do not count.
    
Please contact info@redistrictingdatahub.org for more information.